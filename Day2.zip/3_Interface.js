"use strict";
var s1 = { height: 10, width: 20 };
