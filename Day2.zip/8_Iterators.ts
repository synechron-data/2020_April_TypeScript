// class Queue<T> {
//     private _data: T[] = [];

//     push(d: T) {
//         this._data.push(d);
//     }

//     pop(): T {
//         return this._data.shift();
//     }

//     [Symbol.iterator]() {
//         const self = this;
//         let i = 0;
//         return {
//             next: function () {
//                 let v, d = true;

//                 if (self._data[i] != undefined) {
//                     v = self._data[i];
//                     d = false;
//                     i += 1;
//                 }

//                 return {
//                     value: v,
//                     done: d
//                 }
//             }
//         };
//     }
// }

// ------------------------------------------------------ Generator Syntax
// class Queue<T> {
//     private _data: T[] = [];

//     push(d: T) {
//         this._data.push(d);
//     }

//     pop(): T {
//         return this._data.shift();
//     }

//     *[Symbol.iterator]() {
//         var self = this;
//         for (let i = 0; i < self._data.length; i++) {
//             yield self._data[i];            
//         }
//     }
// }

// -----------------------------------------------------

class Queue<T> {
    private _data: T[] = [];

    push(d: T) {
        this._data.push(d);
    }

    pop(): T {
        return this._data.shift();
    }

    *[Symbol.iterator]() {
        yield* this._data;
    }
}

var numberQ = new Queue<number>();

numberQ.push(10);
numberQ.push(20);
numberQ.push(30);

for (const item of numberQ) {
    console.log(item);
}