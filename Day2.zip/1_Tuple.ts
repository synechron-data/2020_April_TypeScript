// Tuple - Stores a fixed collection of values of same or varied types, maintaining the sequence

// var arr: number[] = [10, 20, 30, 40, 50];
// var arr = new Array<number>(2);
// arr[0] = 1;
// arr[1] = 2;
// arr[2] = 3;

// console.log(arr);
// console.log(arr.length);

// Typeguard Array
// var arr: (string | number)[] = ["Manish", 1];
// arr = ["Abhijeet", "Gole", 2, "Pune"];
// arr = ["Abhijeet", "Gole"];
// arr = [10, 20];
// arr = [1, "Abhijeet"];

let dataRow: [number, string] = [1, "Manish"];
// dataRow = ["Manish", 1];
// dataRow = ["Abhijeet", "Gole"];
// dataRow =  [10, 20];
// dataRow = [1, "Abhijeet", 2, "Pune"];

// for (const data of dataRow) {
//     console.log(data);
// }

console.log(dataRow[0]);
console.log(dataRow[1]);