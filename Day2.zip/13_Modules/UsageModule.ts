import { IPoint, Point } from "./PointModule.js";
import * as $ from 'jquery';

let point: IPoint = new Point(2, 3);
console.log(point.getDistance());

document.getElementById("jsResult").innerHTML =
    point.getDistance().toString();

$(document).ready(() => {
    $("#jqResult").html(point.getDistance().toString());
});