"use strict";
var dataRow = [1, "Manish"];
console.log(dataRow[0]);
console.log(dataRow[1]);
