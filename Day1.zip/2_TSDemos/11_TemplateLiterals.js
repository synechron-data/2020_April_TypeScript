"use strict";
var fname = "Manish";
var lname = "Sharma";
var message = "Hello, " + fname + " " + lname;
console.log(message);
