"use strict";
var Employee = (function () {
    function Employee(name) {
        this._name = name;
    }
    Employee.prototype.getName = function () {
        return this._name;
    };
    Employee.prototype.setName = function (name) {
        this._name = name;
    };
    return Employee;
}());
var e1 = new Employee("Manish");
console.log(e1.getName());
e1.setName("Abhijeet");
console.log(e1.getName());
console.log("\n\n");
var e2 = new Employee("Pravin");
console.log(e2.getName());
e2.setName("Ramakant");
console.log(e2.getName());
