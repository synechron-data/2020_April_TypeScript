const env = "production";
console.log(env);

if (true) {
    const env = "development";
    console.log(env);
}

const obj = { id: 1 };
console.log(obj);
obj.id = 100;
console.log(obj);

// obj = {};