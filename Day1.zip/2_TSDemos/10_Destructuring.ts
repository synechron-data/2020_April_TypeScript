// ---------------------------- Object Destructuring
// var emp = { id: 1, ename: "Manish", city: "Pune", state: "MH", pin: 411021 };

// var id = emp.id;
// var ename = emp.ename;

// var { id, ename } = emp;
// console.log(`Id: ${id}`);
// console.log(`Name: ${ename}`);

// var { id, ename, ...address } = emp;

// console.log(`Id: ${id}`);
// console.log(`Name: ${ename}`);
// console.log(`address: ${JSON.stringify(address)}`);

// ---------------------------- Array Destructuring
var numArr = [10, 20, 30, 40, 50, 60, 70, 80, 90];

// var x = numArr[0];
// var y = numArr[2];

// var [x, , y] = numArr;
// console.log(`x = ${x}, y = ${y}`);

var [x, , y, ...z] = numArr;
console.log(`x = ${x}, y = ${y}, z = ${z}`);

// Swap
// var [x, , y] = numArr;

// console.log(`Before, x = ${x}, y = ${y}`);

// [x, y] = [y, x];

// console.log(`After, x = ${x}, y = ${y}`);
