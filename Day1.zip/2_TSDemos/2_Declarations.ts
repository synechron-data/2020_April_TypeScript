// Implicitly Typed
// var data = 10;
// data = "ABC";

// var s = "ABC";

// var data;
// data = "ABC";
// data = 10;


// Explicitly Typed
// var age: number;
// age = 10;

// var p = new Promise(() => { });
// var s = Symbol("Manish");

// number / string / boolean / undefined / Array / Object / Date / RegExp / Function / void - (Based on, lib section in typescript Configuration)

// any / never / Tuple / Interface / Enum / Class

function add(x: number, y: number) {
    return x + y;
}

console.log(add(2, 3));
console.log(add(2, 4));
// console.log(add(2, "ABC"));