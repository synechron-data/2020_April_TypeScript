// ------------------------------ Array Spread

// var numArr1 = [10, 20, 30, 40, 50];

// // var numArr2 = numArr1;
// // var numArr2 = numArr1.slice();
// var numArr2 = [...numArr1];

// numArr2[0] = 1000;

// console.log("1 - ", numArr1);
// console.log("2 - ", numArr2);

// var numArr1 = [10, 20];
// var numArr2 = [30, 40, 50];

// // var numArr3 = numArr1.concat(numArr2);
// var numArr3 = [...numArr1, ...numArr2];

// console.log("1 - ", numArr1);
// console.log("2 - ", numArr2);
// console.log("3 - ", numArr3);

// ------------------------------ Object Spread
var emp1 = { id: 1, name: "Manish", address: { city: "Pune" } };

// var emp2 = emp1;
// Shallow Copy
// var emp2 = Object.assign({}, emp1);
var emp2 = { ...emp1 };

// Deep Copy
// var emp2 = JSON.parse(JSON.stringify(emp1));

emp2.id = 1000;
emp2.address.city = "Mumbai";

console.log("1 - ", emp1);
console.log("2 - ", emp2);