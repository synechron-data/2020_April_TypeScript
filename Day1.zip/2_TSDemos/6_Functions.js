"use strict";
var employees = [
    { id: 1, name: "ABC", city: "Pune" },
    { id: 2, name: "XYZ", city: "Mumbai" },
    { id: 3, name: "PQR", city: "Pune" }
];
var employee = employees.find(function (item) { return item.id === 2; });
console.log(employee);
var map = new Map(Object.entries({
    one: 1,
    two: 2,
}));
console.log(map);
