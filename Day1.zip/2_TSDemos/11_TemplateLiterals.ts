// var d1 = "Hello";
// var d2 = 'Hello';
// var d3 = `Hello`;

// console.log(typeof d1);
// console.log(typeof d2);
// console.log(typeof d3);

// var d4 = "H\ne\nl\nl\no";
// console.log(d4);

// var d5 = `H
//     e
//         l
//             l
//                 o`;
// console.log(d5);

var fname = "Manish";
var lname = "Sharma";
// var message = "Hello, " + fname + " " + lname;
// console.log(message);

var message = `Hello, ${fname} ${lname}`;
console.log(message);
