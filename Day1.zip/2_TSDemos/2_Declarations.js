"use strict";
function add(x, y) {
    return x + y;
}
console.log(add(2, 3));
console.log(add(2, 4));
