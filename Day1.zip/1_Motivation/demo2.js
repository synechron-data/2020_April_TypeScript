var Employee = (function(){
    function Employee(name) {
        this._name = name;
    }

    Employee.prototype.getName = function () {
        return this._name;
    }

    Employee.prototype.setName = function (name) {
        this._name = name;
    }

    return Employee;
})();

var e1 = new Employee("Manish");
console.log(e1.getName());
e1.setName("Abhijeet");
console.log(e1.getName());

var e2 = new Employee("Pravin");
console.log(e2.getName());
e2.setName("Ramakant");
console.log(e2.getName());

// var i = 10;
// console.log(i);
// console.log(typeof i);

// var f = function () {
//     console.log("Hello World!");
// };
// console.log(f);
// console.log(typeof f);